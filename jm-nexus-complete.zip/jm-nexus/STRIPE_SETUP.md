# 💳 Stripe Payments Setup Guide for JM Nexus

## Overview
The landing page already has the payment modal UI built.
You just need to connect it to a real Stripe account (takes ~10 minutes).

---

## Step 1 — Create a Stripe Account
1. Go to https://stripe.com and sign up (free)
2. Complete your business details to enable payments

---

## Step 2 — Create Payment Links (Easiest Method)

In your Stripe dashboard:
1. Go to **Products** → **Add Product**
2. Create two products:
   - **JM Nexus Pro** — $9/month (recurring)
   - **JM Nexus Lifetime** — $79 (one-time)
3. For each product, click **Create Payment Link**
4. Copy the payment link URL (looks like `https://buy.stripe.com/abc123`)

---

## Step 3 — Add Links to Your Landing Page

Open `landing/index.html` and find this comment:

```javascript
// ⚡ REPLACE THIS with your real Stripe Checkout redirect:
// window.location.href = 'https://buy.stripe.com/YOUR_PAYMENT_LINK';
```

Replace with:
```javascript
window.location.href = 'https://buy.stripe.com/YOUR_ACTUAL_LINK_HERE';
```

---

## Step 4 — Add to Vercel Environment Variables

In your Vercel project settings, also add:
- `VITE_STRIPE_PRO_LINK` = your Pro payment link
- `VITE_STRIPE_LIFETIME_LINK` = your Lifetime payment link

---

## 💰 Expected Revenue Breakdown

| Plan | Price | 10 customers | 50 customers | 100 customers |
|------|-------|-------------|-------------|--------------|
| Pro (monthly) | $9/mo | $90/mo | $450/mo | $900/mo |
| Lifetime | $79 | $790 | $3,950 | $7,900 |

Stripe takes 2.9% + $0.30 per transaction.

---

## Optional: Advanced Integration (Webhooks)

For features like "unlock Pro after payment", you'd need:
1. A backend server (Node.js/Python)
2. Stripe webhooks to verify payments
3. User authentication (e.g. Supabase)

This is for when you have paying customers and want to enforce limits.
Start simple with payment links first!

---

## Test Your Setup

Use Stripe's test card: `4242 4242 4242 4242`
- Any future expiry date
- Any 3-digit CVC

Payments in test mode are free and won't charge anyone.
