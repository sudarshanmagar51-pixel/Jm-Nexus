# JM Nexus AI 🤖

Your intelligent AI companion — powered by Claude.

---

## 🚀 Deploy to Vercel in 5 Minutes

### Step 1 — Get Your Anthropic API Key
1. Go to https://console.anthropic.com/
2. Sign up / log in
3. Click **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`)

### Step 2 — Put Your Code on GitHub
1. Go to https://github.com and create a new repository called `jm-nexus`
2. Upload all these project files to it

### Step 3 — Deploy on Vercel
1. Go to https://vercel.com and sign up (free)
2. Click **"Add New Project"**
3. Import your GitHub repo `jm-nexus`
4. Before clicking Deploy, go to **Environment Variables** and add:
   - Name: `VITE_ANTHROPIC_API_KEY`
   - Value: your API key from Step 1
5. Click **Deploy** ✅

Your app will be live at `https://jm-nexus.vercel.app` (or similar)!

---

## 💻 Run Locally

```bash
# 1. Install dependencies
npm install

# 2. Create your env file
cp .env.example .env.local
# Then edit .env.local and paste your API key

# 3. Start the dev server
npm run dev

# Open http://localhost:5173
```

---

## 📁 Project Structure

```
jm-nexus/
├── public/
│   └── favicon.svg
├── src/
│   ├── JMNexus.jsx     ← Main app component
│   ├── main.jsx        ← React entry point
│   └── index.css       ← Global styles
├── index.html
├── package.json
├── vite.config.js
├── vercel.json
└── .env.example        ← Copy to .env.local with your API key
```

---

## 💰 How to Monetize

1. **Add Stripe** — charge users $9/month for unlimited access
2. **Free tier limit** — give 10 free messages, then require signup
3. **Pro features** — longer memory, faster responses, custom personas

---

Built with React + Vite + Anthropic Claude API
