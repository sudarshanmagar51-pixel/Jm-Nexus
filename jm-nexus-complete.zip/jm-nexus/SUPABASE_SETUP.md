# 🔐 Supabase Login Setup Guide

## What Supabase adds to JM Nexus
- User sign up / sign in / forgot password
- Secure accounts (email + password)
- Foundation for tracking Pro vs Free users

---

## Step 1 — Create a Supabase Project (Free)

1. Go to https://supabase.com and sign up
2. Click **"New Project"**
3. Name it `jm-nexus`, pick a region close to you
4. Set a strong database password (save it!)
5. Wait ~2 minutes for the project to set up

---

## Step 2 — Get Your Keys

In your Supabase project dashboard:
1. Go to **Settings** → **API**
2. Copy:
   - **Project URL** → `https://xxxxx.supabase.co`
   - **anon / public key** → long string starting with `eyJ...`

---

## Step 3 — Add to Vercel Environment Variables

In your Vercel project settings, add:
- `VITE_SUPABASE_URL` = your Project URL
- `VITE_SUPABASE_ANON_KEY` = your anon key
- `VITE_ANTHROPIC_API_KEY` = your Anthropic key (already set)

---

## Step 4 — Enable Email Auth in Supabase

1. In Supabase dashboard → **Authentication** → **Providers**
2. Make sure **Email** is enabled (it is by default)
3. Optional: turn off "Confirm email" during testing so users can log in immediately

---

## Step 5 — Redeploy on Vercel

After adding the new env variables, Vercel will automatically redeploy.
Your app will now show a login screen before the chat!

---

## How It Works

```
User visits JM Nexus
       ↓
AuthGate checks if logged in
       ↓
Not logged in → shows Login/Signup modal
       ↓
Logged in → shows JM Nexus chat
```

The `AuthGate.jsx` component wraps your entire app.
It blocks access until the user is authenticated.

---

## Next Steps (Optional)

Once login works, you can:
1. **Track message counts** per user in Supabase database
2. **Check Pro status** — only allow unlimited messages for paid users
3. **Connect Stripe** — when user pays, update their `is_pro` flag in Supabase

Let me know if you want me to build these features!
