import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const S = {
  overlay: {
    position: "fixed", inset: 0, zIndex: 1000,
    background: "rgba(0,0,0,0.8)", backdropFilter: "blur(8px)",
    display: "flex", alignItems: "center", justifyContent: "center", padding: 24,
  },
  box: {
    background: "#100c1e",
    border: "1px solid rgba(124,58,237,0.3)",
    borderRadius: 24, padding: 40,
    width: "100%", maxWidth: 420,
    boxShadow: "0 0 80px rgba(124,58,237,0.2)",
    animation: "slideUp 0.3s ease",
  },
  logo: {
    width: 52, height: 52, borderRadius: 14, margin: "0 auto 20px",
    background: "linear-gradient(135deg, #7c3aed, #2563eb)",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 18, fontWeight: 800, color: "white",
    boxShadow: "0 0 24px rgba(124,58,237,0.45)",
  },
  title: {
    fontSize: 22, fontWeight: 800, textAlign: "center",
    background: "linear-gradient(90deg, #a78bfa, #60a5fa)",
    WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
    marginBottom: 6,
  },
  sub: { fontSize: 13, color: "#64748b", textAlign: "center", marginBottom: 28 },
  label: { fontSize: 11, fontWeight: 700, color: "#64748b", letterSpacing: "0.5px", display: "block", marginBottom: 6 },
  input: {
    width: "100%", padding: "12px 14px",
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(124,58,237,0.25)",
    borderRadius: 10, color: "#e2e8f0", fontSize: 14,
    fontFamily: "inherit", outline: "none",
    marginBottom: 16, transition: "border-color 0.2s",
  },
  btn: {
    width: "100%", padding: 13, borderRadius: 12,
    background: "linear-gradient(135deg, #7c3aed, #2563eb)",
    color: "white", border: "none", fontSize: 15, fontWeight: 700,
    cursor: "pointer", marginTop: 4,
    boxShadow: "0 0 20px rgba(124,58,237,0.3)",
    transition: "opacity 0.2s",
  },
  toggle: {
    textAlign: "center", marginTop: 20, fontSize: 13, color: "#64748b",
  },
  toggleLink: {
    color: "#a78bfa", cursor: "pointer", fontWeight: 600, background: "none",
    border: "none", fontSize: 13, fontFamily: "inherit",
  },
  error: {
    background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)",
    borderRadius: 10, padding: "10px 14px", fontSize: 13, color: "#fca5a5",
    marginBottom: 16,
  },
  success: {
    background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.3)",
    borderRadius: 10, padding: "10px 14px", fontSize: 13, color: "#86efac",
    marginBottom: 16,
  },
  divider: {
    display: "flex", alignItems: "center", gap: 12, margin: "20px 0",
    fontSize: 12, color: "#475569",
  },
  dividerLine: { flex: 1, height: 1, background: "rgba(124,58,237,0.15)" },
};

export { supabase };

export default function AuthGate({ children }) {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState("login"); // login | signup | forgot
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  if (loading) return (
    <div style={{ minHeight: "100vh", background: "#08040f", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ color: "#7c3aed", fontSize: 14 }}>Loading JM Nexus…</div>
    </div>
  );

  if (session) return children;

  async function handleSubmit() {
    setError(""); setMessage(""); setSubmitting(true);
    try {
      if (mode === "signup") {
        const { error: e } = await supabase.auth.signUp({ email, password });
        if (e) throw e;
        setMessage("Check your email to confirm your account!");
      } else if (mode === "login") {
        const { error: e } = await supabase.auth.signInWithPassword({ email, password });
        if (e) throw e;
      } else if (mode === "forgot") {
        const { error: e } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: window.location.origin,
        });
        if (e) throw e;
        setMessage("Password reset email sent! Check your inbox.");
      }
    } catch (e) {
      setError(e.message || "Something went wrong. Try again.");
    } finally {
      setSubmitting(false);
    }
  }

  function handleKey(e) {
    if (e.key === "Enter") handleSubmit();
  }

  return (
    <div style={S.overlay}>
      <style>{`@keyframes slideUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}`}</style>
      <div style={S.box}>
        <div style={S.logo}>JM</div>
        <div style={S.title}>JM Nexus</div>
        <div style={S.sub}>
          {mode === "login" && "Sign in to your account"}
          {mode === "signup" && "Create your free account"}
          {mode === "forgot" && "Reset your password"}
        </div>

        {error && <div style={S.error}>⚠️ {error}</div>}
        {message && <div style={S.success}>✓ {message}</div>}

        <div>
          <label style={S.label}>EMAIL ADDRESS</label>
          <input
            style={S.input} type="email" placeholder="you@example.com"
            value={email} onChange={e => setEmail(e.target.value)}
            onKeyDown={handleKey}
            onFocus={e => e.target.style.borderColor = "#7c3aed"}
            onBlur={e => e.target.style.borderColor = "rgba(124,58,237,0.25)"}
          />
        </div>

        {mode !== "forgot" && (
          <div>
            <label style={S.label}>PASSWORD</label>
            <input
              style={S.input} type="password"
              placeholder={mode === "signup" ? "Min. 6 characters" : "Your password"}
              value={password} onChange={e => setPassword(e.target.value)}
              onKeyDown={handleKey}
              onFocus={e => e.target.style.borderColor = "#7c3aed"}
              onBlur={e => e.target.style.borderColor = "rgba(124,58,237,0.25)"}
            />
          </div>
        )}

        {mode === "login" && (
          <div style={{ textAlign: "right", marginTop: -8, marginBottom: 16 }}>
            <button style={{ ...S.toggleLink, fontSize: 12 }} onClick={() => { setMode("forgot"); setError(""); setMessage(""); }}>
              Forgot password?
            </button>
          </div>
        )}

        <button
          style={{ ...S.btn, opacity: submitting ? 0.6 : 1 }}
          onClick={handleSubmit}
          disabled={submitting}
        >
          {submitting ? "Please wait…" : mode === "login" ? "Sign in →" : mode === "signup" ? "Create account →" : "Send reset email →"}
        </button>

        <div style={S.toggle}>
          {mode === "login" && <>Don't have an account? <button style={S.toggleLink} onClick={() => { setMode("signup"); setError(""); setMessage(""); }}>Sign up free</button></>}
          {mode === "signup" && <>Already have an account? <button style={S.toggleLink} onClick={() => { setMode("login"); setError(""); setMessage(""); }}>Sign in</button></>}
          {mode === "forgot" && <><button style={S.toggleLink} onClick={() => { setMode("login"); setError(""); setMessage(""); }}>← Back to sign in</button></>}
        </div>

        <div style={{ textAlign: "center", marginTop: 20, fontSize: 11, color: "#374151" }}>
          By continuing, you agree to our{" "}
          <a href="/landing/terms.html" style={{ color: "#6366f1" }}>Terms</a> and{" "}
          <a href="/landing/privacy.html" style={{ color: "#6366f1" }}>Privacy Policy</a>
        </div>
      </div>
    </div>
  );
}
