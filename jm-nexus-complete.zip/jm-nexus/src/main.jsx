import React from 'react'
import ReactDOM from 'react-dom/client'
import JMNexus from './JMNexus.jsx'
import AuthGate from './AuthGate.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthGate>
      <JMNexus />
    </AuthGate>
  </React.StrictMode>,
)
